### Git Test Fixture

This directory is a simple git repository used in some tests to verify git operations we perform